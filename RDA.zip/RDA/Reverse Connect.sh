echo "Scanning for hosts on port 8085..."
export COUNTER=1
 myip=$(ip -4 addr show wlan0 | grep -oP '(?<=inet\s)\d+(\.\d+){2}'.)
while [ $COUNTER -lt 255 ]
do
    nc $myip$COUNTER 8085
    COUNTER=$(( $COUNTER + 1 ))
done