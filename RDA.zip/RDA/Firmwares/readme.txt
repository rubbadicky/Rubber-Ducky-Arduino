Put you device in dfu mode
run sh flashstock.sh
unplug arduino and plug back in
Program your Rubber Dicky
run sh flashhid.sh
unplug arduino