dfu-programmer atmega16u2 erase
dfu-programmer atmega16u2 flash --debug 1 Arduino-usbserial-uno.hex
dfu-programmer atmega16u2 reset
sudo arduino
